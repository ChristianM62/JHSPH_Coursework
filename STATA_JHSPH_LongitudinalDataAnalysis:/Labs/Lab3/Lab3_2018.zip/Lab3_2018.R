## Setwd
setwd("C:\\Users\\Elizabeth\\Dropbox\\LDA2016\\Lab exercises\\Lab3")

## Read in the stroke_trial.csv file
data <- read.table("stroke_trial.csv",sep=",",header=T)

## Tabular and graphical display of the prevalence

tapply(data$y,list(data$A,data$time),mean)

library(ggplot2)
ggplot(data, aes(x=time, y=y, colour=A)) + 
    	geom_errorbar(aes(ymin=y-se, ymax=y+se), width=.1) +
    	geom_line() +
    	geom_point()

## Lasagna Plot

# reference: https://github.com/swihart/lasagnar
# reference: http://www.ncbi.nlm.nih.gov/pmc/articles/PMC2937254/

library(devtools)  
library(maps)
library(spam)
library(scales)
library(gtable)                                                                                                                                 
install_github("swihart/lasagnar")                                                               
library(fields)
library(lasagnar)   
library(ggplot2)
library(reshape2)
library(RColorBrewer)
library(colorspace)  

# reshape to wide format
data_wide = reshape(data[, colnames(data) != "followup"],timevar = c("time"), idvar = c("id","A"),direction="wide")
row.names(data_wide) = data_wide$id

# plot lasagna plot
png("lasagna.png", width = 480*2, height = 480+10)
par(mfrow=c(1,2))
# set up colors
palette <- brewer.pal(6, "Set1")[2:3]
# sort subjects according to their trajectories
data_wide_sorted = data_wide[order(data_wide[,"y.0"], data_wide[,"y.6"], data_wide[,"y.12"], data_wide[,"y.18"]), ]
# plot lasagna for control group
lasagna(data_wide_sorted[data_wide_sorted$A == 0,c("y.0","y.6","y.12","y.18")],col = palette, 
	main = "Lasagna plot, ctrl", legend = T, cex=1)
# plot lasagna for treatment group
lasagna(data_wide_sorted[data_wide_sorted$A == 1,c("y.0","y.6","y.12","y.18")], col = palette, 
	main = "Lasagna plot, trt", legend = T, cex=0.8)
dev.off()

## Compute the pairwise correlation / odds ratios

mytable = table(data_wide[,c("y.0","y.6")])
or = mytable[1,1]*mytable[2,2]/(mytable[1,2]*mytable[2,1])
		
