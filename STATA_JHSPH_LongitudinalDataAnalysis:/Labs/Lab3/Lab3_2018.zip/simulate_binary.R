# R bindata
# generate correlated multivariate binary random variables

library(bindata)

N = 100
rho = 0.5

margprob_ctrl = seq(1,length = 4, by = 0.5)/10
margprob_trt = (1:4)/10

bincorr = matrix(c(1, rho, rho^2, rho^3, 
				   rho, 1, rho^3, rho^2,
				   rho^2, rho^3, 1, rho,  
				   rho^3, rho^2, rho, 1), 
	nrow = 4, byrow = T)

# calculate probability that ith and jth component both be 1
commonprob = function(i, j, margprob_ctrl, bincorr) {
	return(bincorr[i,j]*sqrt(margprob_ctrl[i]*(1-margprob_ctrl[i]))*sqrt(margprob_ctrl[j]*(1-margprob_ctrl[j])) + margprob_ctrl[i]*margprob_ctrl[j])
}

commonprobs_ctrl = matrix(NA, nrow = 4, ncol = 4)
commonprobs_trt = matrix(NA, nrow = 4, ncol = 4)

for(i in 1:length(margprob_ctrl)) {
	for(j in 1:length(margprob_ctrl)) {
		commonprobs_ctrl[i,j] = commonprob(i,j,margprob_ctrl, bincorr)
		commonprobs_trt[i,j] = commonprob(i,j,margprob_trt, bincorr)
	}
}

ctrl = rmvbin(N, commonprob = commonprobs_ctrl)
trt = rmvbin(N, commonprob = commonprobs_trt)

# validation
cor(trt)
cor(ctrl)
apply(trt,2,mean)
apply(ctrl,2,mean)

# Merge the data into one dataset
# and make it a long dataset
data.wide <- as.data.frame(cbind(seq(1,200),c(rep(1,100),rep(0,100)),rbind(trt,ctrl)))
names(data.wide) <- c("id","A","Y1","Y2","Y3","Y4")
library(reshape)
data = reshape(data.wide,timevar = c("time"), varying=3:6,v.names="Y",idvar = c("id","A"),direction="long")
data$followup <- ifelse(data$time==1,0,ifelse(data$time==1,6,ifelse(data$time==2,12,18)))

